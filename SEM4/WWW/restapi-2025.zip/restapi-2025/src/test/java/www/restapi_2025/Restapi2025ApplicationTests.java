package www.restapi_2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Restapi2025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
