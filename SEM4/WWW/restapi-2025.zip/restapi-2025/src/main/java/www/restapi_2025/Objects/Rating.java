package www.restapi_2025.Objects;

public enum Rating {
    Goated,
    Excellent,
    Good,
    Average,
    Bad,
    Horrible,
}
